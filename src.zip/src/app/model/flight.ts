export class Flight{
    public code:number=0;
    public carrier:string="";
    public source:string="";
    public destination:string="";
}